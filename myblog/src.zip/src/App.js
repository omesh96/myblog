
import './App.css';
import Homepage from './Component/Homepage';


function App() {
  return (
    <div className="App">
   <Homepage />
    </div>
  );
}

export default App;
